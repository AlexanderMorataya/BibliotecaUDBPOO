﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Collections;

namespace Log_In
{
    public partial class Alquilar_Libros : Form
    {
        private SqlConnection conn;
        private string sCn;
        public Alquilar_Libros()
        {
            InitializeComponent();
            Conexion CnL = new Conexion();
            CnL.Conec();
            sCn = CnL.cadena;

            conn = new SqlConnection(sCn);
            try
            {
                conn.Open();
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btn_generar_Click(object sender, EventArgs e)
        {
            string query = "SELECT [cliente_id] FROM Cliente WHERE [cliente_id] = " + txtDUI.Text;
            SqlCommand command = new SqlCommand(query, conn);
            try
            {
                SqlDataReader reader = command.ExecuteReader();
                
            }
            catch(Exception ex)
            {
                if(ex.Message=="Error de lectura porque no hay datos.")
                {
                    MessageBox.Show("Cliente no registrado");
                }
                else
                {
                    MessageBox.Show("Ocurrio un error inesperado: " + ex.Message);
                }
            }
        }

        private void rbtn_reserva_CheckedChanged(object sender, EventArgs e)
        {
            lbl_codigo_reserva.Show();
            txtReserva.Show();
            lbl_nombre.Enabled= false;
            lbl_telefono.Enabled= false;
            lbl_Dui.Enabled= false;
            lbl_Codigo_libro.Enabled= false;
            lbl_apellido.Enabled= false;
            lbl_correo.Enabled= false;
            txtApellido.Enabled= false;
            txtCodigo_Libro.Enabled= false;
            txtCorreo.Enabled= false;
            txtDUI.Enabled= false;
            txtNombre.Enabled= false;
            txtTelefono.Enabled= false;
        }

        private void rb_primera_vez_CheckedChanged(object sender, EventArgs e)
        {
            lbl_nombre.Enabled = true;
            lbl_telefono.Enabled = true;
            lbl_Codigo_libro.Enabled = true;
            lbl_apellido.Enabled = true;
            lbl_correo.Enabled = true;
            txtApellido.Enabled = true;
            txtCodigo_Libro.Enabled = true;
            txtCorreo.Enabled = true;
            txtNombre.Enabled = true;
            txtTelefono.Enabled = true;
        }
    }
}
