﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Log_In
{
    public class Usuario_Controlador
    {
        //Constructor
        public Usuario_Controlador() { }
        //Atributos
        public static string UserCode { get; set; }
        public static string UserName { get; set; }
        public static string Password { get; set; }
        public static string Mail { get; set; }   
        public static string Phone { get; set; }
        public static string Dui { get; set; }
        public static string Estatus { get; set; }

    }
}
