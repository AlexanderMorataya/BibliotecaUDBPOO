﻿namespace Log_In
{
    partial class Registro
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Registro));
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.TxtUserName = new System.Windows.Forms.TextBox();
            this.TxtUserGmail = new System.Windows.Forms.TextBox();
            this.TxtUserPhoneNumber = new System.Windows.Forms.TextBox();
            this.TxtUserDUI = new System.Windows.Forms.TextBox();
            this.BtnContinueRg = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label7 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.BtnCloseWindow = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            resources.ApplyResources(this.label1, "label1");
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Name = "label1";
            // 
            // label2
            // 
            resources.ApplyResources(this.label2, "label2");
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Name = "label2";
            // 
            // label3
            // 
            resources.ApplyResources(this.label3, "label3");
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Name = "label3";
            // 
            // label4
            // 
            resources.ApplyResources(this.label4, "label4");
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Name = "label4";
            // 
            // TxtUserName
            // 
            this.TxtUserName.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(33)))), ((int)(((byte)(38)))));
            this.TxtUserName.BorderStyle = System.Windows.Forms.BorderStyle.None;
            resources.ApplyResources(this.TxtUserName, "TxtUserName");
            this.TxtUserName.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.TxtUserName.Name = "TxtUserName";
            // 
            // TxtUserGmail
            // 
            this.TxtUserGmail.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(33)))), ((int)(((byte)(38)))));
            this.TxtUserGmail.BorderStyle = System.Windows.Forms.BorderStyle.None;
            resources.ApplyResources(this.TxtUserGmail, "TxtUserGmail");
            this.TxtUserGmail.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.TxtUserGmail.Name = "TxtUserGmail";
            // 
            // TxtUserPhoneNumber
            // 
            this.TxtUserPhoneNumber.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(33)))), ((int)(((byte)(38)))));
            this.TxtUserPhoneNumber.BorderStyle = System.Windows.Forms.BorderStyle.None;
            resources.ApplyResources(this.TxtUserPhoneNumber, "TxtUserPhoneNumber");
            this.TxtUserPhoneNumber.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.TxtUserPhoneNumber.Name = "TxtUserPhoneNumber";
            // 
            // TxtUserDUI
            // 
            this.TxtUserDUI.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(33)))), ((int)(((byte)(38)))));
            this.TxtUserDUI.BorderStyle = System.Windows.Forms.BorderStyle.None;
            resources.ApplyResources(this.TxtUserDUI, "TxtUserDUI");
            this.TxtUserDUI.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.TxtUserDUI.Name = "TxtUserDUI";
            // 
            // BtnContinueRg
            // 
            this.BtnContinueRg.BackColor = System.Drawing.SystemColors.HotTrack;
            this.BtnContinueRg.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BtnContinueRg.FlatAppearance.BorderSize = 0;
            resources.ApplyResources(this.BtnContinueRg, "BtnContinueRg");
            this.BtnContinueRg.ForeColor = System.Drawing.Color.White;
            this.BtnContinueRg.Name = "BtnContinueRg";
            this.BtnContinueRg.UseVisualStyleBackColor = false;
            this.BtnContinueRg.Click += new System.EventHandler(this.BtnContinueRg_Click);
            // 
            // label6
            // 
            resources.ApplyResources(this.label6, "label6");
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Name = "label6";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(33)))), ((int)(((byte)(38)))));
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.button1);
            this.panel1.Controls.Add(this.BtnCloseWindow);
            resources.ApplyResources(this.panel1, "panel1");
            this.panel1.Name = "panel1";
            // 
            // label7
            // 
            resources.ApplyResources(this.label7, "label7");
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Name = "label7";
            // 
            // button1
            // 
            this.button1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button1.FlatAppearance.BorderSize = 0;
            resources.ApplyResources(this.button1, "button1");
            this.button1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button1.Name = "button1";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // BtnCloseWindow
            // 
            this.BtnCloseWindow.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BtnCloseWindow.FlatAppearance.BorderSize = 0;
            resources.ApplyResources(this.BtnCloseWindow, "BtnCloseWindow");
            this.BtnCloseWindow.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.BtnCloseWindow.Name = "BtnCloseWindow";
            this.BtnCloseWindow.UseVisualStyleBackColor = true;
            this.BtnCloseWindow.Click += new System.EventHandler(this.BtnCloseWindow_Click);
            // 
            // Registro
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(22)))), ((int)(((byte)(25)))), ((int)(((byte)(28)))));
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.BtnContinueRg);
            this.Controls.Add(this.TxtUserDUI);
            this.Controls.Add(this.TxtUserPhoneNumber);
            this.Controls.Add(this.TxtUserGmail);
            this.Controls.Add(this.TxtUserName);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Registro";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox TxtUserName;
        private System.Windows.Forms.TextBox TxtUserGmail;
        private System.Windows.Forms.TextBox TxtUserPhoneNumber;
        private System.Windows.Forms.TextBox TxtUserDUI;
        private System.Windows.Forms.Button BtnContinueRg;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button BtnCloseWindow;
    }
}