﻿namespace Log_In
{
    partial class Alquilar_Libros
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_Alquiler = new System.Windows.Forms.Label();
            this.lbl_nombre = new System.Windows.Forms.Label();
            this.lbl_apellido = new System.Windows.Forms.Label();
            this.lbl_correo = new System.Windows.Forms.Label();
            this.lbl_telefono = new System.Windows.Forms.Label();
            this.lbl_Dui = new System.Windows.Forms.Label();
            this.lbl_Codigo_libro = new System.Windows.Forms.Label();
            this.txtNombre = new System.Windows.Forms.TextBox();
            this.txtApellido = new System.Windows.Forms.TextBox();
            this.txtCorreo = new System.Windows.Forms.TextBox();
            this.txtTelefono = new System.Windows.Forms.TextBox();
            this.txtDUI = new System.Windows.Forms.TextBox();
            this.txtCodigo_Libro = new System.Windows.Forms.TextBox();
            this.rbtn_reserva = new System.Windows.Forms.RadioButton();
            this.txtReserva = new System.Windows.Forms.TextBox();
            this.lbl_codigo_reserva = new System.Windows.Forms.Label();
            this.txt_codigo_alquiler = new System.Windows.Forms.TextBox();
            this.txtcosto = new System.Windows.Forms.TextBox();
            this.lbl_codigo_alquiler = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lbl_Costo = new System.Windows.Forms.Label();
            this.dtp_devolucion = new System.Windows.Forms.DateTimePicker();
            this.btn_cerrar = new System.Windows.Forms.Button();
            this.btn_generar = new System.Windows.Forms.Button();
            this.rb_primera_vez = new System.Windows.Forms.RadioButton();
            this.lbl_fecha_nacimiento = new System.Windows.Forms.Label();
            this.dtp_fecha_nacimiento = new System.Windows.Forms.DateTimePicker();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lbl_Alquiler
            // 
            this.lbl_Alquiler.AutoSize = true;
            this.lbl_Alquiler.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Bold);
            this.lbl_Alquiler.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lbl_Alquiler.Location = new System.Drawing.Point(332, 24);
            this.lbl_Alquiler.Name = "lbl_Alquiler";
            this.lbl_Alquiler.Size = new System.Drawing.Size(288, 39);
            this.lbl_Alquiler.TabIndex = 0;
            this.lbl_Alquiler.Text = "Alquiler de libros";
            // 
            // lbl_nombre
            // 
            this.lbl_nombre.AutoSize = true;
            this.lbl_nombre.Enabled = false;
            this.lbl_nombre.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.5F);
            this.lbl_nombre.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lbl_nombre.Location = new System.Drawing.Point(62, 253);
            this.lbl_nombre.Name = "lbl_nombre";
            this.lbl_nombre.Size = new System.Drawing.Size(62, 18);
            this.lbl_nombre.TabIndex = 1;
            this.lbl_nombre.Text = "Nombre";
            // 
            // lbl_apellido
            // 
            this.lbl_apellido.AutoSize = true;
            this.lbl_apellido.Enabled = false;
            this.lbl_apellido.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.5F);
            this.lbl_apellido.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lbl_apellido.Location = new System.Drawing.Point(62, 293);
            this.lbl_apellido.Name = "lbl_apellido";
            this.lbl_apellido.Size = new System.Drawing.Size(59, 18);
            this.lbl_apellido.TabIndex = 2;
            this.lbl_apellido.Text = "Apellido";
            // 
            // lbl_correo
            // 
            this.lbl_correo.AutoSize = true;
            this.lbl_correo.Enabled = false;
            this.lbl_correo.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.5F);
            this.lbl_correo.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lbl_correo.Location = new System.Drawing.Point(62, 333);
            this.lbl_correo.Name = "lbl_correo";
            this.lbl_correo.Size = new System.Drawing.Size(55, 18);
            this.lbl_correo.TabIndex = 3;
            this.lbl_correo.Text = "Correo";
            // 
            // lbl_telefono
            // 
            this.lbl_telefono.AutoSize = true;
            this.lbl_telefono.Enabled = false;
            this.lbl_telefono.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.5F);
            this.lbl_telefono.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lbl_telefono.Location = new System.Drawing.Point(62, 373);
            this.lbl_telefono.Name = "lbl_telefono";
            this.lbl_telefono.Size = new System.Drawing.Size(66, 18);
            this.lbl_telefono.TabIndex = 4;
            this.lbl_telefono.Text = "Telefono";
            // 
            // lbl_Dui
            // 
            this.lbl_Dui.AutoSize = true;
            this.lbl_Dui.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.5F);
            this.lbl_Dui.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lbl_Dui.Location = new System.Drawing.Point(62, 175);
            this.lbl_Dui.Name = "lbl_Dui";
            this.lbl_Dui.Size = new System.Drawing.Size(33, 18);
            this.lbl_Dui.TabIndex = 5;
            this.lbl_Dui.Text = "DUI";
            // 
            // lbl_Codigo_libro
            // 
            this.lbl_Codigo_libro.AutoSize = true;
            this.lbl_Codigo_libro.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.5F);
            this.lbl_Codigo_libro.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lbl_Codigo_libro.Location = new System.Drawing.Point(62, 213);
            this.lbl_Codigo_libro.Name = "lbl_Codigo_libro";
            this.lbl_Codigo_libro.Size = new System.Drawing.Size(111, 18);
            this.lbl_Codigo_libro.TabIndex = 6;
            this.lbl_Codigo_libro.Text = "Codigo del libro";
            // 
            // txtNombre
            // 
            this.txtNombre.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(56)))), ((int)(((byte)(70)))));
            this.txtNombre.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtNombre.Enabled = false;
            this.txtNombre.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.5F);
            this.txtNombre.ForeColor = System.Drawing.SystemColors.Control;
            this.txtNombre.Location = new System.Drawing.Point(228, 254);
            this.txtNombre.Name = "txtNombre";
            this.txtNombre.Size = new System.Drawing.Size(238, 17);
            this.txtNombre.TabIndex = 7;
            // 
            // txtApellido
            // 
            this.txtApellido.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(56)))), ((int)(((byte)(70)))));
            this.txtApellido.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtApellido.Enabled = false;
            this.txtApellido.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.5F);
            this.txtApellido.ForeColor = System.Drawing.SystemColors.Control;
            this.txtApellido.Location = new System.Drawing.Point(228, 291);
            this.txtApellido.Name = "txtApellido";
            this.txtApellido.Size = new System.Drawing.Size(238, 17);
            this.txtApellido.TabIndex = 8;
            // 
            // txtCorreo
            // 
            this.txtCorreo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(56)))), ((int)(((byte)(70)))));
            this.txtCorreo.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtCorreo.Enabled = false;
            this.txtCorreo.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.5F);
            this.txtCorreo.ForeColor = System.Drawing.SystemColors.Control;
            this.txtCorreo.Location = new System.Drawing.Point(228, 331);
            this.txtCorreo.Name = "txtCorreo";
            this.txtCorreo.Size = new System.Drawing.Size(238, 17);
            this.txtCorreo.TabIndex = 9;
            // 
            // txtTelefono
            // 
            this.txtTelefono.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(56)))), ((int)(((byte)(70)))));
            this.txtTelefono.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtTelefono.Enabled = false;
            this.txtTelefono.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.5F);
            this.txtTelefono.ForeColor = System.Drawing.SystemColors.Control;
            this.txtTelefono.Location = new System.Drawing.Point(228, 371);
            this.txtTelefono.Name = "txtTelefono";
            this.txtTelefono.Size = new System.Drawing.Size(238, 17);
            this.txtTelefono.TabIndex = 10;
            // 
            // txtDUI
            // 
            this.txtDUI.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(56)))), ((int)(((byte)(70)))));
            this.txtDUI.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtDUI.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.5F);
            this.txtDUI.ForeColor = System.Drawing.SystemColors.Control;
            this.txtDUI.Location = new System.Drawing.Point(228, 173);
            this.txtDUI.Name = "txtDUI";
            this.txtDUI.Size = new System.Drawing.Size(238, 17);
            this.txtDUI.TabIndex = 6;
            // 
            // txtCodigo_Libro
            // 
            this.txtCodigo_Libro.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(56)))), ((int)(((byte)(70)))));
            this.txtCodigo_Libro.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtCodigo_Libro.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.5F);
            this.txtCodigo_Libro.ForeColor = System.Drawing.SystemColors.Control;
            this.txtCodigo_Libro.Location = new System.Drawing.Point(228, 214);
            this.txtCodigo_Libro.Name = "txtCodigo_Libro";
            this.txtCodigo_Libro.Size = new System.Drawing.Size(238, 17);
            this.txtCodigo_Libro.TabIndex = 7;
            // 
            // rbtn_reserva
            // 
            this.rbtn_reserva.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.5F);
            this.rbtn_reserva.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.rbtn_reserva.Location = new System.Drawing.Point(65, 454);
            this.rbtn_reserva.Name = "rbtn_reserva";
            this.rbtn_reserva.Size = new System.Drawing.Size(166, 50);
            this.rbtn_reserva.TabIndex = 13;
            this.rbtn_reserva.TabStop = true;
            this.rbtn_reserva.Text = "Tengo un libro reservado";
            this.rbtn_reserva.UseVisualStyleBackColor = true;
            this.rbtn_reserva.CheckedChanged += new System.EventHandler(this.rbtn_reserva_CheckedChanged);
            // 
            // txtReserva
            // 
            this.txtReserva.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(56)))), ((int)(((byte)(70)))));
            this.txtReserva.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtReserva.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.5F);
            this.txtReserva.ForeColor = System.Drawing.SystemColors.Control;
            this.txtReserva.Location = new System.Drawing.Point(228, 517);
            this.txtReserva.Name = "txtReserva";
            this.txtReserva.Size = new System.Drawing.Size(238, 17);
            this.txtReserva.TabIndex = 15;
            this.txtReserva.Visible = false;
            // 
            // lbl_codigo_reserva
            // 
            this.lbl_codigo_reserva.AutoSize = true;
            this.lbl_codigo_reserva.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.5F);
            this.lbl_codigo_reserva.Location = new System.Drawing.Point(62, 514);
            this.lbl_codigo_reserva.Name = "lbl_codigo_reserva";
            this.lbl_codigo_reserva.Size = new System.Drawing.Size(129, 18);
            this.lbl_codigo_reserva.TabIndex = 14;
            this.lbl_codigo_reserva.Text = "Codigo de reserva";
            this.lbl_codigo_reserva.Visible = false;
            // 
            // txt_codigo_alquiler
            // 
            this.txt_codigo_alquiler.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(56)))), ((int)(((byte)(70)))));
            this.txt_codigo_alquiler.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_codigo_alquiler.Enabled = false;
            this.txt_codigo_alquiler.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.5F);
            this.txt_codigo_alquiler.ForeColor = System.Drawing.SystemColors.Control;
            this.txt_codigo_alquiler.Location = new System.Drawing.Point(667, 267);
            this.txt_codigo_alquiler.Name = "txt_codigo_alquiler";
            this.txt_codigo_alquiler.Size = new System.Drawing.Size(201, 17);
            this.txt_codigo_alquiler.TabIndex = 21;
            // 
            // txtcosto
            // 
            this.txtcosto.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(56)))), ((int)(((byte)(70)))));
            this.txtcosto.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtcosto.Enabled = false;
            this.txtcosto.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.5F);
            this.txtcosto.ForeColor = System.Drawing.SystemColors.Control;
            this.txtcosto.Location = new System.Drawing.Point(667, 175);
            this.txtcosto.Name = "txtcosto";
            this.txtcosto.Size = new System.Drawing.Size(201, 17);
            this.txtcosto.TabIndex = 19;
            // 
            // lbl_codigo_alquiler
            // 
            this.lbl_codigo_alquiler.AutoSize = true;
            this.lbl_codigo_alquiler.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.5F);
            this.lbl_codigo_alquiler.Location = new System.Drawing.Point(504, 265);
            this.lbl_codigo_alquiler.Name = "lbl_codigo_alquiler";
            this.lbl_codigo_alquiler.Size = new System.Drawing.Size(126, 18);
            this.lbl_codigo_alquiler.TabIndex = 18;
            this.lbl_codigo_alquiler.Text = "Codigo de alquiler";
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.5F);
            this.label2.Location = new System.Drawing.Point(504, 211);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(105, 40);
            this.label2.TabIndex = 17;
            this.label2.Text = "Fecha de devolucion";
            // 
            // lbl_Costo
            // 
            this.lbl_Costo.AutoSize = true;
            this.lbl_Costo.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.5F);
            this.lbl_Costo.Location = new System.Drawing.Point(504, 175);
            this.lbl_Costo.Name = "lbl_Costo";
            this.lbl_Costo.Size = new System.Drawing.Size(49, 18);
            this.lbl_Costo.TabIndex = 16;
            this.lbl_Costo.Text = "Costo";
            // 
            // dtp_devolucion
            // 
            this.dtp_devolucion.CalendarMonthBackground = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(56)))), ((int)(((byte)(70)))));
            this.dtp_devolucion.Checked = false;
            this.dtp_devolucion.Enabled = false;
            this.dtp_devolucion.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.5F);
            this.dtp_devolucion.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtp_devolucion.Location = new System.Drawing.Point(667, 219);
            this.dtp_devolucion.Name = "dtp_devolucion";
            this.dtp_devolucion.Size = new System.Drawing.Size(201, 24);
            this.dtp_devolucion.TabIndex = 20;
            // 
            // btn_cerrar
            // 
            this.btn_cerrar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btn_cerrar.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.btn_cerrar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.btn_cerrar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.btn_cerrar.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_cerrar.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.btn_cerrar.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.btn_cerrar.Location = new System.Drawing.Point(870, 29);
            this.btn_cerrar.Name = "btn_cerrar";
            this.btn_cerrar.Size = new System.Drawing.Size(42, 34);
            this.btn_cerrar.TabIndex = 22;
            this.btn_cerrar.Text = "X";
            this.btn_cerrar.UseVisualStyleBackColor = true;
            this.btn_cerrar.Click += new System.EventHandler(this.button1_Click);
            // 
            // btn_generar
            // 
            this.btn_generar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(56)))), ((int)(((byte)(70)))));
            this.btn_generar.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.btn_generar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.btn_generar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(70)))), ((int)(((byte)(120)))));
            this.btn_generar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_generar.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.5F);
            this.btn_generar.ForeColor = System.Drawing.SystemColors.Control;
            this.btn_generar.Location = new System.Drawing.Point(801, 500);
            this.btn_generar.Name = "btn_generar";
            this.btn_generar.Size = new System.Drawing.Size(111, 44);
            this.btn_generar.TabIndex = 23;
            this.btn_generar.Text = "Generar";
            this.btn_generar.UseVisualStyleBackColor = false;
            this.btn_generar.Click += new System.EventHandler(this.btn_generar_Click);
            // 
            // rb_primera_vez
            // 
            this.rb_primera_vez.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.5F);
            this.rb_primera_vez.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.rb_primera_vez.Location = new System.Drawing.Point(65, 96);
            this.rb_primera_vez.Name = "rb_primera_vez";
            this.rb_primera_vez.Size = new System.Drawing.Size(270, 50);
            this.rb_primera_vez.TabIndex = 24;
            this.rb_primera_vez.TabStop = true;
            this.rb_primera_vez.Text = "Primera vez alquilando un libro";
            this.rb_primera_vez.UseVisualStyleBackColor = true;
            this.rb_primera_vez.CheckedChanged += new System.EventHandler(this.rb_primera_vez_CheckedChanged);
            // 
            // lbl_fecha_nacimiento
            // 
            this.lbl_fecha_nacimiento.AutoSize = true;
            this.lbl_fecha_nacimiento.Enabled = false;
            this.lbl_fecha_nacimiento.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.5F);
            this.lbl_fecha_nacimiento.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lbl_fecha_nacimiento.Location = new System.Drawing.Point(62, 413);
            this.lbl_fecha_nacimiento.Name = "lbl_fecha_nacimiento";
            this.lbl_fecha_nacimiento.Size = new System.Drawing.Size(145, 18);
            this.lbl_fecha_nacimiento.TabIndex = 25;
            this.lbl_fecha_nacimiento.Text = "Fecha de nacimiento";
            // 
            // dtp_fecha_nacimiento
            // 
            this.dtp_fecha_nacimiento.CalendarMonthBackground = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(56)))), ((int)(((byte)(70)))));
            this.dtp_fecha_nacimiento.Checked = false;
            this.dtp_fecha_nacimiento.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.5F);
            this.dtp_fecha_nacimiento.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtp_fecha_nacimiento.Location = new System.Drawing.Point(228, 413);
            this.dtp_fecha_nacimiento.Name = "dtp_fecha_nacimiento";
            this.dtp_fecha_nacimiento.Size = new System.Drawing.Size(238, 24);
            this.dtp_fecha_nacimiento.TabIndex = 26;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(504, 304);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(278, 18);
            this.label1.TabIndex = 27;
            this.label1.Text = "Por favor guardar codigo de alquiler";
            // 
            // Alquilar_Libros
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(25)))), ((int)(((byte)(28)))));
            this.ClientSize = new System.Drawing.Size(950, 589);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dtp_fecha_nacimiento);
            this.Controls.Add(this.lbl_fecha_nacimiento);
            this.Controls.Add(this.rb_primera_vez);
            this.Controls.Add(this.btn_generar);
            this.Controls.Add(this.btn_cerrar);
            this.Controls.Add(this.dtp_devolucion);
            this.Controls.Add(this.txt_codigo_alquiler);
            this.Controls.Add(this.txtcosto);
            this.Controls.Add(this.lbl_codigo_alquiler);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lbl_Costo);
            this.Controls.Add(this.txtReserva);
            this.Controls.Add(this.lbl_codigo_reserva);
            this.Controls.Add(this.rbtn_reserva);
            this.Controls.Add(this.txtCodigo_Libro);
            this.Controls.Add(this.txtDUI);
            this.Controls.Add(this.txtTelefono);
            this.Controls.Add(this.txtCorreo);
            this.Controls.Add(this.txtApellido);
            this.Controls.Add(this.txtNombre);
            this.Controls.Add(this.lbl_Codigo_libro);
            this.Controls.Add(this.lbl_Dui);
            this.Controls.Add(this.lbl_telefono);
            this.Controls.Add(this.lbl_correo);
            this.Controls.Add(this.lbl_apellido);
            this.Controls.Add(this.lbl_nombre);
            this.Controls.Add(this.lbl_Alquiler);
            this.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Alquilar_Libros";
            this.Text = "Alquilar Libros";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_Alquiler;
        private System.Windows.Forms.Label lbl_nombre;
        private System.Windows.Forms.Label lbl_apellido;
        private System.Windows.Forms.Label lbl_correo;
        private System.Windows.Forms.Label lbl_telefono;
        private System.Windows.Forms.Label lbl_Dui;
        private System.Windows.Forms.Label lbl_Codigo_libro;
        private System.Windows.Forms.TextBox txtNombre;
        private System.Windows.Forms.TextBox txtApellido;
        private System.Windows.Forms.TextBox txtCorreo;
        private System.Windows.Forms.TextBox txtTelefono;
        private System.Windows.Forms.TextBox txtDUI;
        private System.Windows.Forms.TextBox txtCodigo_Libro;
        private System.Windows.Forms.RadioButton rbtn_reserva;
        private System.Windows.Forms.TextBox txtReserva;
        private System.Windows.Forms.Label lbl_codigo_reserva;
        private System.Windows.Forms.TextBox txt_codigo_alquiler;
        private System.Windows.Forms.TextBox txtcosto;
        private System.Windows.Forms.Label lbl_codigo_alquiler;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lbl_Costo;
        private System.Windows.Forms.DateTimePicker dtp_devolucion;
        private System.Windows.Forms.Button btn_cerrar;
        private System.Windows.Forms.Button btn_generar;
        private System.Windows.Forms.RadioButton rb_primera_vez;
        private System.Windows.Forms.Label lbl_fecha_nacimiento;
        private System.Windows.Forms.DateTimePicker dtp_fecha_nacimiento;
        private System.Windows.Forms.Label label1;
    }
}